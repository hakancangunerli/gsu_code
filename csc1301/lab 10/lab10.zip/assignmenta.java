/* 
Hakan Can Gunerli
Lab 10/ Part A CSC1301 Friday 3PM-4.40PM

*/ 


import java.util.Scanner;
public class Main
{
 public static void main(String[] args) {
  int num=5; // 5 rows
  for (int r = 1; r <= num; r++) {
   for (int sp = num - r; sp >= 1; sp--) {
    System.out.print(" ");
   }
   for (int c = 0; c <= r-1; c++) {
    System.out.print(" " + c);
   }
   System.out.println();
  }
 }
}

