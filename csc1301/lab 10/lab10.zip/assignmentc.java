/* 
Hakan Can Gunerli
Lab 10/ Part C  CSC1301 Friday 3PM-4.40PM

*/ 
//assignment c 

public class Main
{
	public static void main(String[] args) {
	

q3();
	}
	

	
	
 public static void q3() {
    int sum = 0;
    int i=0;
    System.out.println("loop 1 ");
    for ( i = 1; i <= 10; i++) {
        sum += i;
        System.out.println(sum);
    
    }
    System.out.println("loop 2 ");
    
    for ( i = 1; sum+i < 100; i++) {
         sum += i;
        System.out.println(sum);

    
 }
     
    }
}

    
    
    








