/* 
Hakan Can Gunerli
Lab 10/ Part B  CSC1301 Friday 3PM-4.40PM

*/ 


import java.util.*;
 
public class Power_of_Things
{
   public static void main(String[] args)
   {  
      System.out.print("Enter the largest of the whole numbers to use: ");
      
            powers();// call the func 

   }
     
      public static void powers(){
                Scanner console = new Scanner(System.in);

      int rows = console.nextInt();
      
                  System.out.print("n^1\t\t"  + "n^2\t\t" + "n^3\t\t" +"n^4\t\t" );// the heads 

      for (int i = 1; i <= rows; i++) 
      {
         System.out.println();    
            
         for (int j = 1; j <= 4; j++)
            System.out.print((int)Math.pow(i,j) +"\t\t");  // do the power
      }    
      }
      
      
   
}
 
